/**
 * Form Builder Core Logic
 * Handles drag & drop, field configuration, and JSON generation.
 */

class FormBuilder {
    constructor(containerId, options = {}) {
        this.container = document.getElementById(containerId);
        if (!this.container) throw new Error(`Container #${containerId} not found`);

        this.options = {
            apiEndpoint: options.apiEndpoint || '/api/forms',
            onSave: options.onSave || null,
            initialData: options.initialData || null
        };

        this.formId = this.options.initialData?.id || null;
        this.formTitle = this.options.initialData?.title || 'Untitled Form';
        this.fields = this.options.initialData?.fields || [];
        this.activeFieldId = null;

        this.fieldTypes = [
            { type: 'text', label: 'Short Text', icon: 'T' },
            { type: 'textarea', label: 'Long Text', icon: '¶' },
            { type: 'email', label: 'Email', icon: '@' },
            { type: 'number', label: 'Number', icon: '123' },
            { type: 'password', label: 'Password', icon: '***' },
            { type: 'select', label: 'Dropdown', icon: '▼' },
            { type: 'radio', label: 'Single Choice', icon: '○' },
            { type: 'checkbox', label: 'Multiple Choice', icon: '☑' },
            { type: 'file', label: 'File Upload', icon: '↑' }
        ];

        this.initUI();
        this.renderCanvas();
    }

    initUI() {
        this.container.innerHTML = `
            <div class="fb-container">
                <div class="fb-sidebar">
                    <div class="fb-sidebar-header">Form Elements</div>
                    <div class="fb-field-list" id="fb-field-list"></div>
                </div>
                
                <div class="fb-main">
                    <div class="fb-header">
                        <input type="text" class="fb-form-title-input" value="${this.formTitle}" id="fb-form-title">
                        <div style="display: flex; gap: 10px;">
                            <button class="fb-btn fb-btn-outline" id="fb-preview-btn">Preview</button>
                            <button class="fb-btn fb-btn-primary" id="fb-save-btn">Save Form</button>
                        </div>
                    </div>
                    <div class="fb-editor">
                        <div class="fb-canvas" id="fb-canvas"></div>
                    </div>
                </div>

                <div class="fb-settings" id="fb-settings-panel" style="display: none;">
                    <div class="fb-settings-header">
                        <span>Field Settings</span>
                        <button class="fb-action-btn" id="fb-close-settings">✕</button>
                    </div>
                    <div class="fb-settings-body" id="fb-settings-body"></div>
                </div>
            </div>
        `;

        // Render sidebar items
        const fieldList = document.getElementById('fb-field-list');
        this.fieldTypes.forEach(ft => {
            const el = document.createElement('div');
            el.className = 'fb-field-item';
            el.innerHTML = `<span style="width: 24px; font-weight: bold; color: var(--fb-primary)">${ft.icon}</span> ${ft.label}`;
            el.draggable = true;
            el.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', ft.type);
            });
            // Click to add support
            el.addEventListener('click', () => {
                this.addField(ft.type);
            });
            fieldList.appendChild(el);
        });

        // Setup Canvas drop
        const canvas = document.getElementById('fb-canvas');
        canvas.addEventListener('dragover', (e) => {
            e.preventDefault();
            canvas.classList.add('drag-over');
        });
        canvas.addEventListener('dragleave', (e) => {
            e.preventDefault();
            canvas.classList.remove('drag-over');
        });
        canvas.addEventListener('drop', (e) => {
            e.preventDefault();
            canvas.classList.remove('drag-over');
            const type = e.dataTransfer.getData('text/plain');
            if (type) this.addField(type);
        });

        // Title sync
        document.getElementById('fb-form-title').addEventListener('input', (e) => {
            this.formTitle = e.target.value;
        });

        // Save
        document.getElementById('fb-save-btn').addEventListener('click', () => this.saveForm());

        // Close Settings
        document.getElementById('fb-close-settings').addEventListener('click', () => {
            this.activeFieldId = null;
            this.renderCanvas();
            document.getElementById('fb-settings-panel').style.display = 'none';
        });

        // Click outside canvas deselects active
        document.querySelector('.fb-editor').addEventListener('click', (e) => {
            if (e.target === document.querySelector('.fb-editor') || e.target === canvas && this.fields.length === 0) {
                this.activeFieldId = null;
                document.getElementById('fb-settings-panel').style.display = 'none';
                this.renderCanvas();
            }
        });
    }

    generateId() {
        return 'field_' + Math.random().toString(36).substr(2, 9);
    }

    addField(type) {
        const baseField = {
            id: this.generateId(),
            type: type,
            label: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
            name: `field_${Date.now()}`,
            required: false,
            placeholder: '',
            options: ['Option 1', 'Option 2'] // Only used for select, radio, checkbox
        };
        this.fields.push(baseField);
        this.activeFieldId = baseField.id;
        this.renderCanvas();
        this.renderSettings();
    }

    removeField(id) {
        this.fields = this.fields.filter(f => f.id !== id);
        if (this.activeFieldId === id) {
            this.activeFieldId = null;
            document.getElementById('fb-settings-panel').style.display = 'none';
        }
        this.renderCanvas();
    }

    duplicateField(id) {
        const field = this.fields.find(f => f.id === id);
        if (field) {
            const clone = JSON.parse(JSON.stringify(field));
            clone.id = this.generateId();
            clone.name = `field_${Date.now()}`;
            this.fields.push(clone);
            this.activeFieldId = clone.id;
            this.renderCanvas();
            this.renderSettings();
        }
    }

    moveField(id, direction) {
        const index = this.fields.findIndex(f => f.id === id);
        if (index < 0) return;
        if (direction === 'up' && index > 0) {
            [this.fields[index - 1], this.fields[index]] = [this.fields[index], this.fields[index - 1]];
        } else if (direction === 'down' && index < this.fields.length - 1) {
            [this.fields[index + 1], this.fields[index]] = [this.fields[index], this.fields[index + 1]];
        }
        this.renderCanvas();
    }

    renderCanvas() {
        const canvas = document.getElementById('fb-canvas');
        canvas.innerHTML = '';

        if (this.fields.length === 0) {
            canvas.innerHTML = `<div class="fb-empty-state">Drag & drop fields here to start building your form.</div>`;
            return;
        }

        this.fields.forEach(field => {
            const el = document.createElement('div');
            el.className = `fb-field-wrapper ${this.activeFieldId === field.id ? 'active' : ''}`;

            // Actions
            const actions = document.createElement('div');
            actions.className = 'fb-field-actions';
            actions.innerHTML = `
                <button class="fb-action-btn" title="Move Up" onclick="event.stopPropagation(); window.__fbInstance.moveField('${field.id}', 'up')">↑</button>
                <button class="fb-action-btn" title="Move Down" onclick="event.stopPropagation(); window.__fbInstance.moveField('${field.id}', 'down')">↓</button>
                <button class="fb-action-btn" title="Duplicate" onclick="event.stopPropagation(); window.__fbInstance.duplicateField('${field.id}')">⧉</button>
                <button class="fb-action-btn delete" title="Delete" onclick="event.stopPropagation(); window.__fbInstance.removeField('${field.id}')">🗑</button>
            `;
            el.appendChild(actions);

            // Preview
            const preview = document.createElement('div');
            let inputHtml = '';

            if (['text', 'email', 'number', 'password'].includes(field.type)) {
                inputHtml = `<input type="${field.type}" class="fb-preview-input" placeholder="${field.placeholder}" disabled>`;
            } else if (field.type === 'textarea') {
                inputHtml = `<textarea class="fb-preview-input" placeholder="${field.placeholder}" disabled></textarea>`;
            } else if (field.type === 'select') {
                inputHtml = `<select class="fb-preview-input" disabled>
                    <option value="">Select option</option>
                    ${field.options.map(o => `<option>${o}</option>`).join('')}
                </select>`;
            } else if (field.type === 'radio' || field.type === 'checkbox') {
                inputHtml = `<div style="display:flex; flex-direction:column; gap:8px;">
                    ${field.options.map(o => `
                        <label style="display:flex; align-items:center; gap:8px;">
                            <input type="${field.type}" disabled> ${o}
                        </label>
                    `).join('')}
                </div>`;
            } else if (field.type === 'file') {
                inputHtml = `<input type="file" class="fb-preview-input" disabled>`;
            }

            preview.innerHTML = `
                <label class="fb-preview-label">${field.label} ${field.required ? '<span style="color:red">*</span>' : ''}</label>
                ${inputHtml}
            `;
            el.appendChild(preview);

            el.addEventListener('click', (e) => {
                e.stopPropagation();
                this.activeFieldId = field.id;
                this.renderCanvas();
                this.renderSettings();
            });

            canvas.appendChild(el);
        });

        // Global reference for inline event handlers
        window.__fbInstance = this;
    }

    renderSettings() {
        if (!this.activeFieldId) return;

        const field = this.fields.find(f => f.id === this.activeFieldId);
        if (!field) return;

        const panel = document.getElementById('fb-settings-panel');
        const body = document.getElementById('fb-settings-body');

        panel.style.display = 'flex';

        let optionsHtml = '';
        if (['select', 'radio', 'checkbox'].includes(field.type)) {
            optionsHtml = `
                <div class="fb-setting-group">
                    <label class="fb-setting-label">Options</label>
                    <div class="fb-options-list" id="fb-options-${field.id}">
                        ${field.options.map((opt, i) => `
                            <div class="fb-option-item">
                                <input type="text" class="fb-setting-input" value="${opt}" data-index="${i}" oninput="window.__fbInstance.updateOption('${field.id}', ${i}, this.value)">
                                <button class="fb-btn fb-btn-outline" onclick="window.__fbInstance.removeOption('${field.id}', ${i})">✕</button>
                            </div>
                        `).join('')}
                    </div>
                    <button class="fb-btn fb-btn-outline" style="width:100%; margin-top:8px;" onclick="window.__fbInstance.addOption('${field.id}')">+ Add Option</button>
                </div>
            `;
        }

        body.innerHTML = `
            <div class="fb-setting-group">
                <label class="fb-setting-label">Field Label</label>
                <input type="text" class="fb-setting-input" value="${field.label}" oninput="window.__fbInstance.updateField('${field.id}', 'label', this.value)">
            </div>
            <div class="fb-setting-group">
                <label class="fb-setting-label">Field Name (API Key)</label>
                <input type="text" class="fb-setting-input" value="${field.name}" oninput="window.__fbInstance.updateField('${field.id}', 'name', this.value)">
            </div>
            ${['text', 'email', 'number', 'password', 'textarea'].includes(field.type) ? `
                <div class="fb-setting-group">
                    <label class="fb-setting-label">Placeholder</label>
                    <input type="text" class="fb-setting-input" value="${field.placeholder}" oninput="window.__fbInstance.updateField('${field.id}', 'placeholder', this.value)">
                </div>
            ` : ''}
            ${optionsHtml}
            <div class="fb-setting-group">
                <label class="fb-setting-checkbox">
                    <input type="checkbox" ${field.required ? 'checked' : ''} onchange="window.__fbInstance.updateField('${field.id}', 'required', this.checked)">
                    <span class="fb-setting-label" style="margin:0;">Required field</span>
                </label>
            </div>
        `;
    }

    updateField(id, key, value) {
        const field = this.fields.find(f => f.id === id);
        if (field) {
            field[key] = value;
            this.renderCanvas(); // Re-render canvas but keep settings open
        }
    }

    updateOption(id, index, value) {
        const field = this.fields.find(f => f.id === id);
        if (field && field.options) {
            field.options[index] = value;
            this.renderCanvas();
        }
    }

    removeOption(id, index) {
        const field = this.fields.find(f => f.id === id);
        if (field && field.options && field.options.length > 1) {
            field.options.splice(index, 1);
            this.renderSettings();
            this.renderCanvas();
        }
    }

    addOption(id) {
        const field = this.fields.find(f => f.id === id);
        if (field && field.options) {
            field.options.push(`Option ${field.options.length + 1}`);
            this.renderSettings();
            this.renderCanvas();
        }
    }

    async saveForm() {
        const btn = document.getElementById('fb-save-btn');
        const origText = btn.innerText;
        btn.innerText = 'Saving...';
        btn.disabled = true;

        const payload = {
            title: this.formTitle,
            fields: this.fields
        };

        try {
            let res;
            if (this.formId) {
                // Update
                res = await fetch(`${this.options.apiEndpoint}/${this.formId}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            } else {
                // Create
                res = await fetch(this.options.apiEndpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
            }

            if (!res.ok) throw new Error('Failed to save');
            const data = await res.json();
            this.formId = data.id;

            if (this.options.onSave) {
                this.options.onSave(data);
            } else {
                alert('Form saved successfully! Form ID: ' + data.id);
            }
        } catch (err) {
            console.error(err);
            alert('Error saving form');
        } finally {
            btn.innerText = origText;
            btn.disabled = false;
        }
    }
}

// Export for module systems or attach to window
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FormBuilder;
} else {
    window.FormBuilder = FormBuilder;
}
