/**
 * Form Renderer Logic
 * Embed script intended to be used on any website
 */

class FormRenderer {
    static async init(options) {
        const { containerId, formId, apiEndpoint = '/api/forms' } = options;
        const container = document.getElementById(containerId);

        if (!container) {
            console.error(`FormRenderer: Container #${containerId} not found.`);
            return;
        }

        container.innerHTML = `<div class="fbr-loading">Loading form...</div>`;

        try {
            const res = await fetch(`${apiEndpoint}/${formId}`);
            if (!res.ok) throw new Error('Form not found or server error');
            const formConfig = await res.json();

            new FormRendererInstance(container, formConfig, apiEndpoint);
        } catch (err) {
            console.error(err);
            container.innerHTML = `<div class="fbr-alert fbr-alert-error">Failed to load form. Please try again later.</div>`;
        }
    }
}

class FormRendererInstance {
    constructor(container, config, apiEndpoint) {
        this.container = container;
        this.config = config;
        this.apiEndpoint = apiEndpoint;
        this.render();
    }

    render() {
        // Generate HTML
        let html = `<div class="fbr-container">`;
        if (this.config.title) {
            html += `<h2 style="margin-top:0; margin-bottom: 20px; font-size:1.5rem; color:#111827;">${this.config.title}</h2>`;
        }

        html += `<form id="fbr-form-${this.config.id}" class="fbr-form" novalidate>`;
        html += `<div id="fbr-msg-${this.config.id}"></div>`;

        this.config.fields.forEach(field => {
            html += this.renderField(field);
        });

        html += `
                <button type="submit" class="fbr-submit-btn" id="fbr-submit-${this.config.id}">Submit</button>
            </form>
        </div>`;

        this.container.innerHTML = html;

        // Attach Event Listeners
        const formEl = document.getElementById(`fbr-form-${this.config.id}`);
        formEl.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    renderField(field) {
        const requiredAttr = field.required ? 'required' : '';
        const requiredMark = field.required ? `<span class="fbr-required-mark">*</span>` : '';
        const nameAttr = `name="${field.name}"`;
        const idAttr = `id="fbr_${field.id}"`;

        let inputHtml = '';

        switch (field.type) {
            case 'text':
            case 'email':
            case 'number':
            case 'password':
                inputHtml = `<input type="${field.type}" class="fbr-input" ${idAttr} ${nameAttr} placeholder="${field.placeholder || ''}" ${requiredAttr}>`;
                break;
            case 'textarea':
                inputHtml = `<textarea class="fbr-textarea" ${idAttr} ${nameAttr} placeholder="${field.placeholder || ''}" ${requiredAttr}></textarea>`;
                break;
            case 'select':
                inputHtml = `
                    <select class="fbr-select" ${idAttr} ${nameAttr} ${requiredAttr}>
                        <option value="">Select option...</option>
                        ${(field.options || []).map(opt => `<option value="${opt}">${opt}</option>`).join('')}
                    </select>`;
                break;
            case 'radio':
                inputHtml = `<div class="fbr-radio-group">
                    ${(field.options || []).map((opt, i) => `
                        <label class="fbr-radio-label">
                            <input type="radio" class="fbr-radio" ${nameAttr} value="${opt}" ${requiredAttr}>
                            ${opt}
                        </label>
                    `).join('')}
                </div>`;
                break;
            case 'checkbox':
                // Checkboxes mapped to an array using name[]
                inputHtml = `<div class="fbr-checkbox-group">
                    ${(field.options || []).map((opt, i) => `
                        <label class="fbr-checkbox-label">
                            <input type="checkbox" class="fbr-checkbox" name="${field.name}[]" value="${opt}">
                            ${opt}
                        </label>
                    `).join('')}
                </div>`;
                break;
            case 'file':
                inputHtml = `<input type="file" class="fbr-input" style="padding: 7px 10px;" ${idAttr} ${nameAttr} ${requiredAttr}>`;
                break;
        }

        return `
            <div class="fbr-field-group" id="fbr-group-${field.id}">
                <label class="fbr-label" for="fbr_${field.id}">${field.label} ${requiredMark}</label>
                ${inputHtml}
                <div class="fbr-error-msg">This field is required.</div>
            </div>
        `;
    }

    async handleSubmit(e) {
        e.preventDefault();

        const formEl = e.target;
        const msgEl = document.getElementById(`fbr-msg-${this.config.id}`);
        const submitBtn = document.getElementById(`fbr-submit-${this.config.id}`);

        // Basic Validation
        let isValid = true;
        this.config.fields.forEach(field => {
            const groupEl = document.getElementById(`fbr-group-${field.id}`);
            if (!groupEl) return;
            groupEl.classList.remove('fbr-group-error');

            if (field.required) {
                if (field.type === 'radio') {
                    const checked = formEl.querySelector(`input[name="${field.name}"]:checked`);
                    if (!checked) {
                        groupEl.classList.add('fbr-group-error');
                        isValid = false;
                    }
                } else if (field.type === 'checkbox') {
                    // Checkbox arrays are tricky, at least one is required if field is required
                    const checked = formEl.querySelectorAll(`input[name="${field.name}[]"]:checked`);
                    if (checked.length === 0) {
                        groupEl.classList.add('fbr-group-error');
                        isValid = false;
                    }
                } else {
                    const input = formEl.querySelector(`[name="${field.name}"]`);
                    if (!input || !input.value.trim()) {
                        groupEl.classList.add('fbr-group-error');
                        isValid = false;
                    }
                }
            }
        });

        if (!isValid) return;

        // Collect Data
        const formData = new FormData(formEl);
        const data = {};

        for (let [key, value] of formData.entries()) {
            if (key.endsWith('[]')) {
                const cleanKey = key.replace('[]', '');
                if (!data[cleanKey]) data[cleanKey] = [];
                data[cleanKey].push(value);
            } else {
                data[key] = value; // Radio or standard input will overwrite nicely
            }
        }

        // Submit via API
        try {
            submitBtn.disabled = true;
            submitBtn.innerText = 'Submitting...';
            msgEl.innerHTML = '';

            const res = await fetch(`${this.apiEndpoint}/${this.config.id}/submissions`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });

            if (!res.ok) throw new Error('Submission failed');

            msgEl.innerHTML = `<div class="fbr-alert fbr-alert-success">Successfully submitted! Thank you.</div>`;
            formEl.reset();

        } catch (err) {
            console.error(err);
            msgEl.innerHTML = `<div class="fbr-alert fbr-alert-error">Failed to submit form. Please try again.</div>`;
        } finally {
            submitBtn.disabled = false;
            submitBtn.innerText = 'Submit';
        }
    }
}

// Export for module systems or attach to window
if (typeof module !== 'undefined' && module.exports) {
    module.exports = FormRenderer;
} else {
    window.FormRenderer = FormRenderer;
}
