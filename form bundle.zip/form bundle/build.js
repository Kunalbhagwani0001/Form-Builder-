const fs = require('fs');
const path = require('path');

const srcDir = path.join(__dirname, 'src');
const distDir = path.join(__dirname, 'dist');

// Simple minifier logic (removes comments and extra spaces)
function simpleMinifyJS(code) {
    return code
        .replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '') // Remove comments
        .replace(/\s+/g, ' ')                    // Collapse whitespace
        .trim();
}

function simpleMinifyCSS(code) {
    return code
        .replace(/\/\*[\s\S]*?\*\//g, '')        // Remove CSS comments
        .replace(/\s+/g, ' ')                    // Collapse whitespace
        .replace(/\s*{\s*/g, '{')                // Remove spaces around braces
        .replace(/\s*}\s*/g, '}')
        .replace(/\s*:\s*/g, ':')                // Remove spaces around colons
        .replace(/\s*;\s*/g, ';')                // Remove spaces around semicolons
        .trim();
}

console.log('Building /dist files...');

['builder', 'renderer'].forEach(module => {
    const jsPath = path.join(srcDir, module, `form-${module}.js`);
    const cssPath = path.join(srcDir, module, `form-${module}.css`);

    if (fs.existsSync(jsPath)) {
        const jsCode = fs.readFileSync(jsPath, 'utf8');
        const minJs = simpleMinifyJS(jsCode);
        fs.writeFileSync(path.join(distDir, `form-${module}.min.js`), minJs, 'utf8');
        console.log(`- Compiled form-${module}.min.js (${minJs.length} bytes)`);
    }

    if (fs.existsSync(cssPath)) {
        const cssCode = fs.readFileSync(cssPath, 'utf8');
        const minCss = simpleMinifyCSS(cssCode);
        fs.writeFileSync(path.join(distDir, `form-${module}.min.css`), minCss, 'utf8');
        console.log(`- Compiled form-${module}.min.css (${minCss.length} bytes)`);
    }
});

console.log('Build complete! Ready for production deployment.');
