const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files to make it easy to test local examples
app.use('/src', express.static(path.join(__dirname, '../src')));
app.use('/examples', express.static(path.join(__dirname, '../examples')));
app.use('/dist', express.static(path.join(__dirname, '../dist')));

// Data file paths
const formsFile = path.join(__dirname, 'data', 'forms.json');
const submissionsFile = path.join(__dirname, 'data', 'submissions.json');

// Helper to read JSON files
const readData = (file) => {
    try {
        if (!fs.existsSync(file)) return [];
        return JSON.parse(fs.readFileSync(file, 'utf8'));
    } catch (e) {
        return [];
    }
};

// Helper to write JSON files
const writeData = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
};

// ---------------------------------------------------------
// API ROUTES
// ---------------------------------------------------------

// Create a new form
app.post('/api/forms', (req, res) => {
    const forms = readData(formsFile);
    const newForm = {
        id: Date.now().toString(),
        title: req.body.title || 'Untitled Form',
        fields: req.body.fields || [],
        settings: req.body.settings || {},
        createdAt: new Date().toISOString()
    };
    forms.push(newForm);
    writeData(formsFile, forms);
    res.status(201).json(newForm);
});

// Get all forms
app.get('/api/forms', (req, res) => {
    const forms = readData(formsFile);
    res.json(forms);
});

// Get a single form by ID
app.get('/api/forms/:id', (req, res) => {
    const forms = readData(formsFile);
    const form = forms.find(f => f.id === req.params.id);
    if (!form) return res.status(404).json({ error: 'Form not found' });
    res.json(form);
});

// Update a form
app.put('/api/forms/:id', (req, res) => {
    const forms = readData(formsFile);
    const index = forms.findIndex(f => f.id === req.params.id);
    if (index === -1) return res.status(404).json({ error: 'Form not found' });
    
    forms[index] = { ...forms[index], ...req.body, id: forms[index].id };
    writeData(formsFile, forms);
    res.json(forms[index]);
});

// Delete a form
app.delete('/api/forms/:id', (req, res) => {
    let forms = readData(formsFile);
    forms = forms.filter(f => f.id !== req.params.id);
    writeData(formsFile, forms);
    res.json({ success: true });
});

// Submit data to a form
app.post('/api/forms/:id/submissions', (req, res) => {
    const forms = readData(formsFile);
    const form = forms.find(f => f.id === req.params.id);
    if (!form) return res.status(404).json({ error: 'Form not found' });

    // In a real app we'd validate the req.body against form.fields here
    
    const submissions = readData(submissionsFile);
    const newSubmission = {
        id: Date.now().toString(),
        formId: req.params.id,
        data: req.body,
        submittedAt: new Date().toISOString()
    };
    submissions.push(newSubmission);
    writeData(submissionsFile, submissions);
    res.status(201).json({ success: true, submissionId: newSubmission.id });
});

// Get submissions for a form
app.get('/api/forms/:id/submissions', (req, res) => {
    const submissions = readData(submissionsFile);
    const formSubmissions = submissions.filter(s => s.formId === req.params.id);
    res.json(formSubmissions);
});

// Simple Login (Admin)
app.post('/api/auth/login', (req, res) => {
    const { username, password } = req.body;
    // Hardcoded for demo simplicity without needing real auth setup
    if (username === 'admin' && password === 'password') {
        return res.json({ token: 'demo-token-123', user: { username: 'admin' } });
    }
    res.status(401).json({ error: 'Invalid credentials' });
});

app.listen(PORT, () => {
    console.log(`Form Builder Backend running on http://localhost:${PORT}`);
});
